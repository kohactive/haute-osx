#!/bin/sh

#  run.sh
#  FontPrep
#
#  Created by Brian M. Gonzalez on 6/11/13.
#  Copyright (c) 2013 gnzlz. All rights reserved

cd ../server && /usr/bin/ruby ./app.rb $1 $2
